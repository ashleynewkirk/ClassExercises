package Store;

import java.time.LocalTime;


public abstract class Store {

    public Store() {
    }

    public Store(String name, String address, int squareFeet,
                 Boolean openSaturday, Boolean openSunday,
                 LocalTime openAt, LocalTime closedAt) {
        this.name = name;
        this.address = address;
        this.squareFeet = squareFeet;
        this.openSaturday = openSaturday;
        this.openSunday = openSunday;
        this.openAt = openAt;
        this.closedAt = closedAt;
    }

    public Store(String name, String address) {
        this.name = name;
        this.address = address;

    }




    private String name, address;
    private int squareFeet;
    private Boolean openSaturday, openSunday;
    private LocalTime openAt, closedAt;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getSquareFeet() {
        return squareFeet;
    }

    public void setSquareFeet(int squareFeet) {
        this.squareFeet = squareFeet;
    }

    public Boolean getOpenSaturday() {
        return openSaturday;
    }

    public void setOpenSaturday(Boolean openSaturday) {
        this.openSaturday = openSaturday;
    }

    public Boolean getOpenSunday() {
        return openSunday;
    }

    public void setOpenSunday(Boolean openSunday) {
        this.openSunday = openSunday;
    }

    public LocalTime getOpenAt() {
        return openAt;
    }

    public void setOpenAt(int hr, int min) {
        this.openAt = LocalTime.of(hr, min);
    }

    public LocalTime getlosedAt() {
        return closedAt;
    }

    public void setclosedAt(int hr, int min) {
        this.openAt = LocalTime.of(hr, min);
    }
    public boolean isOpen (){
        return LocalTime.now().isAfter(openAt) && LocalTime.now().isBefore(closedAt);
    }
}
