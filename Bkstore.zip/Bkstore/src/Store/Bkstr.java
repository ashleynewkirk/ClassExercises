package Store;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.stream.Stream;


public class Bkstr extends Store {

    Boolean hasUsedBooks;
    private ArrayList<String> titles;

    public Bkstr(String name, String address) {
        super(name, address);
        titles = new ArrayList<>();
        loadTitles();
        titleHasWord("Python");


    }

    public static class Utils
    {
        public static void loadStringsToArray(ArrayList<String> arrList) throws IOException
        {
            Path path = Paths.get("BookTitles.txt");
            arrList.clear();

            // The stream file will also be closed here
            try (Stream<String> lines = Files.lines(path))
            {
                Object[] arr = lines.toArray();

                for(Object t: arr)
                {
                    arrList.add(t.toString());
                }
            }
        }

    }


    public Bkstr(String name, String address, int squareFeet,
                 Boolean openSaturday, Boolean openSunday, LocalTime openAt,
                 LocalTime closedAt) {
        super(name, address, squareFeet, openSaturday, openSunday, openAt, closedAt);

    }



    public boolean hasUsedBooks() {
        return hasUsedBooks;
    }
    public void sethasUsedBooks(boolean hasUsedBooks){
        this.hasUsedBooks= hasUsedBooks;
    }


    private void loadTitles() {
        try {
            Utils.loadStringsToArray(this.titles);
        } catch (IOException e) {
            // for now simply init the array to zero
            System.out.println("Could not initialize the titles");
            // make sure it is empty
            this.titles = new ArrayList<>();

        }


    }
    public int numBooks(){
        return titles.size();
    }
    public boolean hasBook(String nameOfBook){
        return titles.contains(nameOfBook);

    }

    public boolean titleHasWord(String word){
        for (String item: titles){
            if (item.contains(word)) return true;
        }
        return false;
    }

}

