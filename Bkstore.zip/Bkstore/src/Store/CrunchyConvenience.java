package Store;

import java.time.LocalTime;

public class CrunchyConvenience extends Store{
    public CrunchyConvenience() {
    }

    public CrunchyConvenience(String name, String address, int squareFeet,
                              Boolean openSaturday, Boolean openSunday,
                              LocalTime openAt, LocalTime closedAt) {
        super(name, address, squareFeet, openSaturday, openSunday, openAt, closedAt);
    }

    public CrunchyConvenience(String name, String address) {
        super(name, address);
    }
}
