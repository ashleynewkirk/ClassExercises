package Store;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.stream.Stream;

public class CrunchySandwiches extends Store {

    public CrunchySandwiches() {

    }

    public CrunchySandwiches(String name, String address, int squareFeet, Boolean openSaturday, Boolean openSunday, LocalTime openAt, LocalTime closedAt) {
        super(name, address, squareFeet, openSaturday, openSunday, openAt, closedAt);

    }

    public CrunchySandwiches(String name, String address) {
        super(name, address);
    }

}
