import Store.Bkstr;

import Store.CrunchyCoffee;
import Store.CrunchySandwiches;

import java.util.Scanner;

import java.sql.SQLOutput;
import java.util.*;
import java.time.LocalTime;

public class Main {
    public static void main(String[] args) {
        Bkstr that = new Bkstr("A's Books", "321 Hope Ave.");
        that.sethasUsedBooks(true);
        that.setOpenSaturday(true);
        that.setOpenSunday(false);
        that.titleHasWord("Python");

        System.out.println("Name and location of bookstore: " + that.getName()+ " at "+ that.getAddress());
        System.out.println("Does the bookstore have used books? " + that.hasUsedBooks());
        System.out.println("The bookstore has " + that.numBooks() + " books");
        System.out.println("The bookstore is open Saturday: " + that.getOpenSaturday());
        System.out.println("The bookstore is open Sunday: " + that.getOpenSunday());
        System.out.println("The bookstore has a book on Python? " + that.titleHasWord("Python "));
    


        CrunchySandwiches cs = new CrunchySandwiches("Crunchy Sandwiches", 320 + " Hope Avenue");
        cs.setAddress(320 + " Hope Avenue");
        cs.setOpenAt(6, 30);
        cs.setSquareFeet(2000);
        cs.setOpenSaturday(true);
        cs.setOpenSunday(true);

        System.out.println("Name and location of shop: " + cs.getName()+ " at "+ cs.getAddress());
        System.out.println("The shop is open Saturday: " + cs.getOpenSaturday());
        System.out.println("The shop is open Sunday: " + cs.getOpenSunday());
        System.out.println("How large is the store:  " + cs.getSquareFeet());
        System.out.println("What time does the store open: " + cs.getOpenAt());
    }
}
