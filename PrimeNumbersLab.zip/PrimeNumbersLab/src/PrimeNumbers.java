import java.sql.SQLOutput;
import java.util.*;
import java.util.Scanner;


public class PrimeNumbers {

    //prints out prime numbers from 1-100

    public static void main(String[] args) {
        int i = 0;
        int num = 0;

        String pNumbers = "";

        for (i = 1; i <= 100; i++) {
            int counter = 0;
            for (num = i; num >= 1; num--) {
                if (i % num == 0) {
                    counter = counter + 1;
                }
            }
            if (counter == 2) {
                //Appended the Prime number to the String
                pNumbers = pNumbers + i + " ";
            }

        }

        System.out.println("Prime numbers from 1 to 100 are :");
        System.out.println(pNumbers);
        isPrime();

    }


    public static void isPrime() {
        int temp;
        boolean isPrime = true;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter any number:");

        int num = scan.nextInt();
        for (int i = 2; i <= num / 2; i++) {
            temp = num % i;
            if (temp == 0) {
                isPrime = false;
                break;
            }
        }
        //If isPrime is true then the number is prime else not
        if (isPrime)
            System.out.println(num + " is a Prime Number");
        else {
            System.out.println(num + " is not a Prime Number");
        }

    }
}








/*Assignment:** Write a Java program to print out all the prime numbers between 1 and 100.

 **Required:** Write and use a function **isPrime()** to tell if a number is prime or not.

 **Extra** **Credit****:** Students who enter college in a year that is a prime number and graduate,
 * four years later, in a year that is also a prime number are considered in a Prime Class. For example,
 * the class of 1997 is a Prime Class as both 1993 and 1997 are prime numbers. Write a program to compute
 * and print out all the prime classes between 1900 and 2100. */