package Species;

public class Sloth extends Animal {
    public Sloth(String name) {
        super(name,"Bradypus", "Chordata");

    }

    @Override
    public void animalInfo() {System.out.println("Name: " + name + " the sloth \n" + "Genus: " +
                genus + "\n" + "phylum: " + phylum);
    }

    @Override
    public void eat() {System.out.println(name + " likes fruit and leaves.");
    }

    @Override
    public void sleep() {System.out.println(name + " sleeps 15-20 hours per day.");
    }

    @Override
    public void run() {
        System.out.println(name + " runs slowly. ");

    }





}


