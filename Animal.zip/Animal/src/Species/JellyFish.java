package Species;

public class JellyFish extends Animal {
    public JellyFish(String name, String genus, String phylum) {
        super(name, genus, phylum);

    }

    @Override
    public void animalInfo() {
        System.out.println("Name: " + name + " the jellyfish \n" + "Genus: " +
                genus + "\n" + "phylum: " + phylum);
    }

    @Override
    public void eat() {
        System.out.println(name + " eats planktonic organisms, crustaceans, and small fish.");
    }

    @Override
    public void sleep() {
        System.out.println(name + " sleeps despite not having a brain.");
    }

    @Override
    public void run() {
        System.out.println (name + " floats. ");

    }
}