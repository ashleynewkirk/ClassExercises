package Species;

public class Lemur extends Animal {


    public Lemur(String name, String genus, String phylum) {
        super(name, genus,phylum);

    }
    @Override
    public void animalInfo(){
        System.out.println("Name: "+ name + " the lemur \n"+ "Genus: " +
                genus + "\n" + "phylum: " + phylum);
    }
    @Override
    public void eat(){
        System.out.println( name + " eats fruit.");
    }

    @Override
    public void sleep(){
        System.out.println(name + " is diurnal.");
    }
    @Override
    public void run(){
        System.out.println(name + " runs slowly. ");

    }

}
