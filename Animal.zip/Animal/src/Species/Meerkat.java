package Species;

public class Meerkat extends Animal {
    public Meerkat(String name, String genus, String phylum) {
        super(name, genus,phylum);

    }
    @Override
    public void animalInfo(){
        System.out.println("Name: "+ name + " the meerkat \n"+ "Genus: " +
                genus + "\n" + "phylum: " + phylum);
    }
    @Override
    public void eat(){
        System.out.println( name + " eats insects.");
    }

    @Override
    public void sleep(){
        System.out.println( name + " is diurnal.");
    }
    @Override
    public void run(){
        System.out.println( name + " runs 30 mph. ");

    }
}
