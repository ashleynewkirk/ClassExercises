import Species.*;

public class Main {

    public static void main(String[] args) {
        Lemur lemur = new Lemur("Lenny", "Lemur", "Chordata");
        lemur.animalInfo();
        lemur.eat();
        lemur.sleep();
        lemur.run();
        System.out.println("\n");


        JellyFish jellyFish = new JellyFish("Jason", "Chrysaora", "Cnidaria");
        jellyFish.animalInfo();
        jellyFish.eat();
        jellyFish.sleep();
        jellyFish.run();
        System.out.println("\n");



        Sloth sloth = new Sloth (" Sid");
        sloth.animalInfo();
        sloth.eat();
        sloth.sleep();
        sloth.run();
        System.out.println("\n");


        Panther panther = new Panther("Pauline", "Panthera", "Chordata");
        panther.animalInfo();
        panther.eat();
        panther.sleep();
        panther.run();
        System.out.println("\n");


        Meerkat meerkat = new Meerkat("Mira", "Suricatta", "Chordata");
        meerkat.animalInfo();
        meerkat.eat();
        meerkat.sleep();
        meerkat.run();
        System.out.println("\n");


        BlackMamba blackmamba = new BlackMamba ("Betty", "Dendroaspis", "Chordata");
        blackmamba.animalInfo();
        blackmamba.eat();
        blackmamba.sleep();
        blackmamba.run();
        System.out.println("\n");

        Scorpion scorpion = new Scorpion ("Sasha","Scorpiops", "Anthropoda" );
        scorpion.animalInfo();
        scorpion.eat();
        scorpion.sleep();
        scorpion.run();
        System.out.println("\n");

        BullShark bullShark = new BullShark("Bella", "Heterodontus", "Chordata");
        bullShark.animalInfo();
        bullShark.eat();
        bullShark.sleep();
        bullShark.run();
        System.out.println("\n");

        Tiger tiger = new Tiger ("Timmy", "Panthera", "Chordata");
        tiger.animalInfo();
        tiger.eat();
        tiger.sleep();
        tiger.run();
        System.out.println("\n");

        Toucan toucan = new Toucan ("Tristan", "Ramphastos", "Chordata");
        toucan.animalInfo();
        toucan.eat();
        toucan.sleep();
        toucan.run();
        System.out.println("\n");

    }

}
