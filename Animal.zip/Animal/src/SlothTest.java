import Species.Sloth;
import org.junit.jupiter.api.*;

import java.io.*;
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class SlothTest {
    PipedInputStream is = new PipedInputStream();
    PipedOutputStream os = new PipedOutputStream(is);
    PrintStream ps = System.out;
    BufferedReader br = new BufferedReader(new InputStreamReader(is));

    Sloth Sid = new Sloth("Sid");

    public SlothTest() throws IOException {
    }

    @BeforeAll
    public  void prepare() {
        System.setOut(new PrintStream(os));
    }

    @Test
    public void animalInfo() {
        Sid.animalInfo();
    }

    private void assertPrinted(String expected) {
        try {
            for (int i = 0; i< expected.split("\n").length;i++)
                Assertions.assertEquals(expected.split("\n")[i], br.readLine());
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void eat() {

        Sid.eat();
        assertPrinted("Sid likes fruit and leaves.");
    }

    @Test
    public void sleep() {

        Sid.sleep();
        assertPrinted("Sid sleeps 15-20 hours per day.");

    }

    @Test
    public void run() {
        Sid.run();
        assertPrinted("Sid runs slowly. ");

    }

    @AfterAll
    public void restoreOut() {
        System.setOut(ps);
    }
}