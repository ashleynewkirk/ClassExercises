package Species;

public class Tiger extends Animal {
    public Tiger(String name, String genus, String phylum) {
        super(name, genus, phylum);

    }

    @Override
    public void animalInfo() {
        System.out.println("Name: " + name + " the tiger \n" + "Genus: " +
                genus + "\n" + "phylum: " + phylum);
    }

    @Override
    public void eat() {
        System.out.println( name + " eats deer, hogs, and boar.");
    }

    @Override
    public void sleep() {
        System.out.println(name + " is diurnal.");
    }

    @Override
    public void run() {
        System.out.println(name + " runs up to 40 mph! ");

    }
}