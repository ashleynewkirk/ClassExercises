package Species;

public class Animal {


    String name;
    String phylum;
    String genus;

    public Animal(String name, String genus, String phylum) {
        this.name = name;
        this.genus= genus;
        this.phylum = phylum;
    }

        public void animalInfo() {

        }

        public void eat() {
            System.out.println("I'm a carnivore.");

        }

        public void sleep() {
            System.out.println("I like to attack.");

        }

        public void run() {
            System.out.println("I like to run.");
        }
}


