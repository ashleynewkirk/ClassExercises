package Species;

public class BullShark extends Animal{
    public BullShark(String name, String genus, String phylum) {
        super(name, genus, phylum);

    }

    @Override
    public void animalInfo() {
        System.out.println("Name: " + name + " the bull shark \n" + "Genus: " +
                genus + "\n" + "phylum: " + phylum);
    }

    @Override
    public void eat() {
        System.out.println( name + " bony fish, small sharks, and stingrays.");
    }

    @Override
    public void sleep() {
        System.out.println(name + " is nocturnal.");
    }

    @Override
    public void run() {
        System.out.println(name + " doesn't run, but swims at 25 mph. ");

    }
}
