package Species;

public class Scorpion extends Animal {
    public Scorpion(String name, String genus, String phylum) {
        super(name, genus, phylum);

    }

    @Override
    public void animalInfo() {
        System.out.println("Name: " + name + " the scorpion \n" + "Genus: " +
                genus + "\n" + "phylum: " + phylum);
    }

    @Override
    public void eat() {
        System.out.println( name + " eats small arthropods, lizards, and snakes.");
    }

    @Override
    public void sleep() {
        System.out.println(name + " is nocturnal.");
    }

    @Override
    public void run() {
        System.out.println(name + " moves swiftly (eight legs)! ");

    }
}
