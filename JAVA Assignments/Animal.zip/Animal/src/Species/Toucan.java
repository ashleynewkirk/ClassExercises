package Species;

public class Toucan extends Animal {
    public Toucan(String name, String genus, String phylum) {
        super(name, genus, phylum);

    }

    @Override
    public void animalInfo() {
        System.out.println("Name: " + name + " the toucan \n" + "Genus: " +
                genus + "\n" + "phylum: " + phylum);
    }

    @Override
    public void eat() {
        System.out.println( name + " eats fruit.");
    }

    @Override
    public void sleep() {
        System.out.println(name + " is diurnal.");
    }

    @Override
    public void run() {
        System.out.println(name + " flies, but is not a very good flier, so she hops from tree to tree instead. ");

    }
}
