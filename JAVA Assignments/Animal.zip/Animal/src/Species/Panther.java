package Species;

public class Panther extends Animal {
    public Panther(String name, String genus, String phylum) {
        super(name, genus, phylum);

    }

    @Override
    public void animalInfo() {
        System.out.println("Name: " + name + " the panther \n" + "Genus: " +
                genus + "\n" + "phylum: " + phylum);
    }

    @Override
    public void eat() {
        System.out.println( name + " eats antelope and deer.");
    }

    @Override
    public void sleep() {
        System.out.println(name + " is nocturnal.");
    }

    @Override
    public void run() {
        System.out.println(name + " runs swiftly. ");

    }
}
